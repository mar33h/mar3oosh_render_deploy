from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import time

app = Flask(__name__)
CORS(app)

openai.api_key = "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"

def log_request(question, answer):
    with open("/root/mar3oosh_logs.txt", "a") as log:
        log.write(f"[{time.ctime()}]\nQ: {question}\nA: {answer}\n\n")

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    question = data.get("question", "")
    auth = data.get("auth", "")
    if auth != "mar3oosh-key-911":
        return jsonify({"error": "Unauthorized access."})
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "أنت مساعد ناري ترد بتحليل واقعي تقني دقيق."},
                {"role": "user", "content": question}
            ]
        )
        answer = response.choices[0].message.content
        log_request(question, answer)
        return jsonify({"answer": answer})
    except Exception as e:
        return jsonify({"error": str(e)}})
